% ========================= ROLES =========================
rol(guitarra).
rol(bateria).
rol(bajo).
rol(vocal).
rol(teclado).

% =========== MIEMBROS BASE (ya tienen experiencia) ========
base(juan, guitarra).
base(pedro, bateria).
base(lucas, vocal).

% =========== ARTISTAS CONTRATADOS (sin experiencia) =======
contratado(sofia).
contratado(martin).
contratado(ana).

:- dynamic entrenado/2.  % <- necesario para assert

% RESET para no acumular datos
reset_entrenados :- retractall(entrenado(_, _)).

% ======== �ROL CUBIERTO? ========
cubierto(R) :- base(_, R).
cubierto(R) :- entrenado(_, R).

% ======== CALCULAR ENTRENAMIENTOS NECESARIOS ============
entrenamientos_necesarios(Cant) :-
    findall(R, rol(R), Roles),
    cubrir_roles(Roles, 0, Cant).

cubrir_roles([], C, C).

cubrir_roles([R|Rest], Acum, CantFinal) :-
    cubierto(R),
    cubrir_roles(Rest, Acum, CantFinal).

cubrir_roles([R|Rest], Acum, CantFinal) :-
    \+ cubierto(R),
    contratado(C),
    asserta(entrenado(C, R)),
    Acum2 is Acum + 1,
    cubrir_roles(Rest, Acum2, CantFinal).
