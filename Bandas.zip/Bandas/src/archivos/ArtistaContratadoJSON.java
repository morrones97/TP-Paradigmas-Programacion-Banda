package archivos;

import java.util.ArrayList;

public class ArtistaContratadoJSON {
	ArrayList<String> rolesEntrenados;
	int cantCancionesMaxRecital;
	double costoPorCancion;
	
    public ArrayList<String> getRolesEntrenados() { return rolesEntrenados; }
    public int getCantCancionesMaxRecital() { return cantCancionesMaxRecital; }
    public double getCostoPorCancion() { return costoPorCancion; }
}
