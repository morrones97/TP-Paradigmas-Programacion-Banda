package archivos;

import java.util.List;

public class ArtistaData {
	List<ArtistaJson> artistas;
	
    public List<ArtistaJson> getArtistas() {
        return artistas;
    }
}
