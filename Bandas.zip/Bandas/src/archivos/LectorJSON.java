package archivos;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.gson.Gson;

import artistas.Artista;
import artistas.ArtistaContratado;
import artistas.Rol;
import canciones.Cancion;
import recitales.Recital;

public class LectorJSON {
    
    public static void leerArchivoArtistas(String nombreArchivo, Set<Artista> artBase,
            Set<ArtistaContratado> artCont, Set<Rol> roles) throws FileNotFoundException {
        
        Gson gson = new Gson();
        FileReader reader = new FileReader("data/" + nombreArchivo);
        ArtistaData data = gson.fromJson(reader, ArtistaData.class);
        
        for (ArtistaJson a : data.getArtistas()) {
            Set<Rol> rolesBase = new HashSet<>();
            Set<String> bandasArtista = new HashSet<>();

            // Historico de roles
            ArrayList<String> historicoRolesArch = a.getHistoricoRoles();  
            for (String r : historicoRolesArch) {
                roles.add(new Rol(r));
                rolesBase.add(new Rol(r));
            }

            // Historico bandas
            String name = a.getName();
            ArrayList<String> historicoBandasArch = a.getHistoricoBandas();  
            bandasArtista.addAll(historicoBandasArch);

            // Datos específicos del artista contratado (si es contratado)
            ArtistaContratadoJSON ac = a.getArtistaContratado();
            
            if (ac != null) {
                Set<Rol> rolesEntrenados = new HashSet<>();

                ArrayList<String> rolesEntrenadosArch = ac.getRolesEntrenados();
                for (String r : rolesEntrenadosArch) {
                    roles.add(new Rol(r));
                    rolesEntrenados.add(new Rol(r));
                }

                double costoCancion = ac.getCostoPorCancion();
                int cantCancionesMax = ac.getCantCancionesMaxRecital();

                ArtistaContratado nuevo = new ArtistaContratado(
                        name,
                        rolesBase,
                        bandasArtista,
                        costoCancion,
                        cantCancionesMax,
                        rolesEntrenados
                );

                // -------------------------------------- MODIFICACION PUNTO BONUS 1 --------------------------------------
                // cargar los tipos de recital donde es estrella (BONUS)
                ArrayList<String> tiposEstrella = a.getTiposRecitalEstrella();
                if (tiposEstrella != null) {
                    nuevo.setTiposRecitalEstrella(new HashSet<>(tiposEstrella));
                }
                // --------------------------------------------------------------------------------------------------------

                artCont.add(nuevo);
                
            } else {
                artBase.add(new Artista(name, rolesBase, bandasArtista)); 
            }
        }
    }
    
    public static Recital leerArchivoRecital(String nombreArchivo) 
            throws FileNotFoundException {
        
        Gson gson = new Gson();
        FileReader reader = new FileReader("data/" + nombreArchivo);
        
        RecitalJson data = gson.fromJson(reader, RecitalJson.class);

        Set<Cancion> canciones = new HashSet<>();
        String tituloRecital = data.getTitulo();
        String bandaRecital = data.getBanda();

        // Construir canciones
        for (CancionJson c : data.getCanciones()) {
            String tituloCancion = c.getTitulo();
            HashMap<Rol, Integer> roles = new HashMap<>();

            for (Map.Entry<String, Integer> ent : c.getRolesRequeridos().entrySet()) {
                Rol rol = new Rol(ent.getKey());
                roles.put(rol, roles.getOrDefault(rol, 0) + ent.getValue());
            }

            canciones.add(new Cancion(tituloCancion, roles));
        }

        Recital recital = new Recital(tituloRecital, bandaRecital, canciones);

        // -------------------------------------- MODIFICACION PUNTO BONUS 1 --------------------------------------
        // cargar tipoRecital (necesario para artista estrella) (BONUS)
        if (data.getTipoRecital() != null) {
            recital.setTipoRecital(data.getTipoRecital());
        }
        // --------------------------------------------------------------------------------------------------------

        return recital;
    }
}

